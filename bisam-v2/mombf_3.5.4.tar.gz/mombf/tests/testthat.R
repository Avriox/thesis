library(testthat)
library(mombf)

test_check("mombf")
